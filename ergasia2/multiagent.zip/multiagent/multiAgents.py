# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        remainingFood = newFood.asList()
        foodDistance = []
        
        if remainingFood:
          for newPos in remainingFood:
            distance = manhattanDistance(newPos, newPos)
            foodDistance.append(distance)
        
        if foodDistance:
          closestFood = min(foodDistance)
        else:
          closestFood = 0
          
        ghostDistance = []
        for ghost in newGhostStates:
          if ghost.scaredTimer == 0:  
            position = ghost.getPosition()
            distance = manhattanDistance(newPos, position)
            ghostDistance.append(distance)
        
        if ghostDistance:
          closestGhost = min(ghostDistance)
        else:
          closestGhost = 0
          
        return successorGameState.getScore() - closestFood + closestGhost

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
      maxv = -float('inf')
      newaction = None

      for action in gameState.getLegalActions(0):
        newv = self.MinValue(gameState.generateSuccessor(0, action), 1, 0)

        if newv > maxv:
            maxv = newv
            newaction = action
      
      return newaction 


    def MaxValue(self, gameState, depth):
      if gameState.isWin() or gameState.isLose() or depth == self.depth:
        return self.evaluationFunction(gameState)

      v = -float('inf')
      for action in gameState.getLegalActions(0):
        v = max(v, self.MinValue(gameState.generateSuccessor(0, action), 1, depth))
      
      return v


    def MinValue(self, gameState, agentIndex, depth):
      if gameState.isWin() or gameState.isLose():
        return self.evaluationFunction(gameState)

      v = float('inf')
      
      if agentIndex < gameState.getNumAgents()-1:
        for action in gameState.getLegalActions(agentIndex):
          v = min(v, self.MinValue(gameState.generateSuccessor(agentIndex, action), agentIndex + 1, depth))
      else:
        for action in gameState.getLegalActions(agentIndex):
          v = min(v, self.MaxValue(gameState.generateSuccessor(agentIndex, action), depth + 1))
      
      return v


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
      maxv = -float('inf')
      a = -float('inf')
      b = float('inf')
      newaction = None

      for action in gameState.getLegalActions(0):
        newv = self.MinValue(gameState.generateSuccessor(0, action), 1, 0, a, b)

        if newv > maxv:
            maxv = newv
            newaction = action
        if newv > b:
          return v
        a = max(a,newv)
      return newaction 


    def MaxValue(self, gameState, depth, a, b):
      if gameState.isWin() or gameState.isLose() or depth == self.depth:
        return self.evaluationFunction(gameState)

      v = -float('inf')
      for action in gameState.getLegalActions(0):
        v = max(v, self.MinValue(gameState.generateSuccessor(0, action), 1, depth, a, b))
        if v > b:
          return v
        a = max(a, v)
      return v


    def MinValue(self, gameState, agentIndex, depth, a, b):
      if gameState.isWin() or gameState.isLose():
        return self.evaluationFunction(gameState)

      v = float('inf')
      if agentIndex < gameState.getNumAgents() - 1:
        for action in gameState.getLegalActions(agentIndex):
          v = min(v, self.MinValue(gameState.generateSuccessor(agentIndex, action), agentIndex + 1,depth, a, b))
          
          if v < a:
            return v
          
          b = min(b,v)
      else:
        for action in gameState.getLegalActions(agentIndex):
          v = min(v, self.MaxValue(gameState.generateSuccessor(agentIndex, action), depth + 1, a, b))
          
          if v < a:
            return v
          
          b = min(b,v)
      
      return v

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
      maxv = -float('inf')

      newaction = None
      for action in gameState.getLegalActions(0):
        newv = self.ExpectedValue(gameState.generateSuccessor(0, action), 1, 0)

        if newv > maxv:
            maxv = newv
            newaction = action

      return newaction 


    def MaxValue(self, gameState, depth):
      if gameState.isWin() or gameState.isLose() or depth == self.depth:
        return self.evaluationFunction(gameState)

      v = -float('inf')
      for action in gameState.getLegalActions(0):
        v = max(v, self.ExpectedValue(gameState.generateSuccessor(0, action), 1, depth))
      return v


    def ExpectedValue(self, gameState, agentIndex, depth):
      if gameState.isWin() or gameState.isLose():
        return self.evaluationFunction(gameState)

      v = 0
      if agentIndex < gameState.getNumAgents() - 1:
        for action in gameState.getLegalActions(agentIndex):
          prob = 1.0 / len(gameState.getLegalActions(agentIndex))
          v += self.ExpectedValue(gameState.generateSuccessor(agentIndex, action), agentIndex + 1, depth) * prob
      
      else:
        for action in gameState.getLegalActions(agentIndex):
          prob = 1.0 / len(gameState.getLegalActions(agentIndex))
          v += self.MaxValue(gameState.generateSuccessor(agentIndex, action), depth + 1) * prob
      
      return v

def betterEvaluationFunction(currentGameState):
    currPos = currentGameState.getPacmanPosition()
    newFood = currentGameState.getFood()
    GhostStates = currentGameState.getGhostStates()
    ScaredTimes = [ghostState.scaredTimer for ghostState in GhostStates]
    capsules = currentGameState.getCapsules()
    remainingFood = newFood.asList()

    if currentGameState.isWin():
      return float('inf')

    if currentGameState.isLose():
      return -float('inf')

    if not remainingFood: 
      closestFood = 0
    else:
      foodDistance = []
      
      for foodPos in remainingFood:
        distance = manhattanDistance(currPos, foodPos)
        foodDistance.append(distance)
      
      closestFood = min(foodDistance)

    if not capsules:
      closestCapsule = 0
    else:
      capsuleDistance = []
      
      for capPos in capsules:
        distance = manhattanDistance(currPos, capPos)
        capsuleDistance.append(distance)
      
      closestCapsule = min(capsuleDistance)
    
    ghostDistance = []
    bonus = 0
    
    for ghost in GhostStates:
      ghostPos = ghost.getPosition()
      distance = manhattanDistance(currPos, ghostPos)
      
      if ghost.scaredTimer == 0:
        ghostDistance.append(distance)
      else:
        if ghost.scaredTimer > distance:
          bonus += (ghost.scaredTimer - distance) * 10
    
    if not ghostDistance:
      closestGhost = len(GhostStates)
    else:
      closestGhost = min(ghostDistance)

    return currentGameState.getScore() - closestFood - len(remainingFood) + closestGhost + closestCapsule + bonus

# Abbreviation
better = betterEvaluationFunction
