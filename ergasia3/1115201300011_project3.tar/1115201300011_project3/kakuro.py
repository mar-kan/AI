from csp import *
from search import *
from utils import *
import sys
import time

# 4x5 puzzle, very easy (ekfonisis)
kakuroPuzzle1 = [['B','B','B',[6,'-'],[3,'-']],['B',[4,'-'],[3,3],'W','W'],[['-',10],'W','W','W','W'],[['-',3],'W','W','B','B']]
# 8x8 puzzle, easy
kakuroPuzzle2 = [['B','B',[11,'-'],[4,'-'],'B','B',[11,'-'],[7,'-'],'B'],['B',['-',4],'W','W',[15,'-'],['-',4],'W','W',[4,'-']],['B',[11,6],'W','W','W',[16,6],'W','W','W'],[['-',3],'W','W',['-',15],'W','W','W','W','W'],[['-',14],'W','W',[11,7],'W','W','W',[11,'-'],[3,'-']],['B',[13,'-'],[6,7],'W','W','W',['-',7],'W','W'],[['-',23],'W','W','W','W','W',[4,4],'W','W'],[['-',14],'W','W','W',['-',6],'W','W','W','B'],['B',['-',3],'W','W','B',['-',4],'W','W','B']]
# 9x11 puzzle, easy
kakuroPuzzle3 = [['B','B','B',[6,'-'],[12,'-'],'B',[10,'-'],[6,'-'],'B','B'],['B',[9,'-'],[21,14],'W','W',['-',3],'W','W','B','B'],[['-',14],'W','W','W','W',[41,8],'W','W',[27,'-'],[16,'-']],[['-',16],'W','W',[13,'-'],['-',3],'W','W',[8,9],'W','W'],['B',['-',9],'W','W',[17,33],'W','W','W','W','W'],['B',[27,'-'],[21,24],'W','W','W',[16,6],'W','W','W'],[['-',14],'W','W',[13,24],'W','W','W',[8,12],'W','W'],[['-',22],'W','W','W',[11,24],'W','W','W',[19,'-'],'B'],[['-',17],'W','W','W','W','W',['-',6],'W','W',[11,'-']],[['-',16],'W','W',[10,5],'W','W',[11,'-'],[10,17],'W','W'],['B','B',['-',14],'W','W',['-',12],'W','W','W','W'],['B','B',['-',4],'W','W',['-',17],'W','W','B','B']]
# 8x8 puzzle, intermediate
kakuroPuzzle4 = [['B',[22,'-'],[31,'-'],'B',[7,'-'],[20,'-'],'B',[6,'-'],[15,'-']],[['-',7],'W','W',[10,12],'W','W',[19,13],'W','W'],[['-',44],'W','W','W','W','W','W','W','W'],[['-',24],'W','W','W',['-',3],'W','W',[30,'-'],'B'],[['-',16],'W','W',[7,'-'],[18,11],'W','W','W',[12,'-']],['B',['-',8],'W','W','W','B',[6,9],'W','W'],['B',[3,'-'],[16,12],'W','W',[14,12],'W','W','W'],[['-',42],'W','W','W','W','W','W','W','W'],[['-',10],'W','W',['-',7],'W','W',['-',6],'W','W']]



class Kakuro(CSP):

	def __init__(self,inputPuzzle):
		self.kakuroPuzzle = inputPuzzle
		self.variables = []
		self.domains = {}
		self.neighbors = {}
		self.rowSums = {}
		self.columnSums = {}
		self.sumPosition = {}

		# Set variables
		for i in range(0,len(inputPuzzle)):
			for j in range(0,len(inputPuzzle[i])):
				if inputPuzzle[i][j] == 'W':
					self.variables.append((i,j))
		# print("\n")
		# print(self.variables)

		# Set domain for each variable
		for variable in self.variables:
			validNumberList = [1,2,3,4,5,6,7,8,9]
			self.domains[variable] = validNumberList
		# print("\n")
		# print(self.domains)

		# Set neighbors
		for variable in self.variables:
			neighborList = []
			x = variable[0]
			y = variable[1]
			# neighbors-variables of the same row (right and left)
			if y != (len(inputPuzzle[x])-1) :
				for j in range(y+1,len(inputPuzzle[x])):
					if inputPuzzle[x][j] != 'W':
						break;
					neighborList.append((x,j))
			if y!=0:
				for j in range(y-1,0,-1):
					if inputPuzzle[x][j] != 'W':
						break;
					neighborList.append((x,j))
			# neighbors-variables of the same column (down and up)
			if x != (len(inputPuzzle)-1):
				for i in range(x+1,len(inputPuzzle)):
					if inputPuzzle[i][y] != 'W':
						break;
					neighborList.append((i,y))
			if x != 0:
				for i in range(x-1,0,-1):
					if inputPuzzle[i][y] != 'W':
						break;
					neighborList.append((i,y))
			self.neighbors[variable] = neighborList
		# print("\n")
		# print(self.neighbors)

		# Save the sums (row, column or both) and the variables that are needed for them
		for i in range(0,len(inputPuzzle)):
			for j in range(0,len(inputPuzzle[i])):
				if type(inputPuzzle[i][j]) == list: # so it is a square with a sum
					# there are three options: 
					# 1) it has two numbers e.g [3,3] ---> both row and column sum
					# 2) it has only one up e.g. ['-',10] ---> row sum
					# 3) it has only one down e.g. [6,'-'] ---> column sum
					temp = inputPuzzle[i][j]
					self.sumPosition[(i,j)] = (temp[0],temp[1])
					if (temp[1] != '-'): # row sum
						rowSumList = []
						# the variables needed are on the right in the same row (until there is no white square)
						for k in range(j+1,len(inputPuzzle[i])):
							if inputPuzzle[i][k] != 'W':
								break
							rowSumList.append((i,k))
						self.rowSums[(i,j)] = rowSumList
					if (temp[0] != '-'): # column sum
						columnSumList = []
						# the variables needed are "down" in the same column (until there is no white square)
						for k in range(i+1,len(inputPuzzle)):
							if inputPuzzle[k][j] != 'W':
								break
							columnSumList.append((k,j))
						self.columnSums[(i,j)] = columnSumList
		# print("\n")
		# print(self.sumPosition)
		# print("\n")
		# print(self.rowSums)
		# print("\n")
		# print(self.columnSums)
		
		CSP.__init__(self, self.variables, self.domains, self.neighbors, self.constraints)

	def constraints(self,A,a,B,b):
		if (a == b) : # same value
			return False

		# Find for which sum these variables are neighbors
		resultkey = (0,0)
		sumvarList = []
		row = False
		for key in self.rowSums.keys():
			tempList = self.rowSums.get(key)
			if A in tempList and B in tempList:
				resultkey = key
				row = True
				break
		if not row:
			for key in self.columnSums.keys():
				tempList = self.columnSums.get(key)
				if A in tempList and B in tempList:
					resultkey = key
					break
		if row:
			sumvarList = self.rowSums.get(resultkey)
			tSquare = self.sumPosition.get(resultkey)
			target = tSquare[1]
		else:
			sumvarList = self.columnSums.get(resultkey)
			tSquare = self.sumPosition.get(resultkey)
			target = tSquare[0]

		getAssignments = self.infer_assignment()
		getAsDict = {}
		count = 0
		for assignment in getAssignments:
			value = getAssignments[assignment]
			# keep only the variables needed and their values
			if assignment in sumvarList:
				getAsDict[assignment] = value
				if (assignment != A) and (assignment != B):
					count += 1
				if (count == (len(sumvarList)-2)):
					break
		getAsDict[A] = a
		getAsDict[B] = b
		count +=2
		getSum = sum(getAsDict.values())
		if count == len(sumvarList):
			if getSum != target:
				return False
		else:
			if getSum >= target:
				return False
		return True


# ----- Main -----
if (len(sys.argv) != 3) :
	print("Error: Invalid Arguments. Please give input puzzle and algorithm.")
if (sys.argv[1] == 'kakuroPuzzle1'):
	inPuzzle = list(kakuroPuzzle1)
elif (sys.argv[1] == 'kakuroPuzzle2'):
	inPuzzle = list(kakuroPuzzle2)
elif (sys.argv[1] == 'kakuroPuzzle3'):
	inPuzzle = list(kakuroPuzzle3)
elif (sys.argv[1] == 'kakuroPuzzle4'):
	inPuzzle = list(kakuroPuzzle4)
else:
	print("Invalid puzzle.")
	sys.exit(0)

algorithm = sys.argv[2]
if (algorithm != 'bt') and (algorithm != 'btmrv') and (algorithm != 'fc') and (algorithm != 'fcmrv'):
	print("Invalid algorithm.")
	sys.exit(0)

k = Kakuro(inPuzzle)

print("Testing",sys.argv[1],"with",algorithm,"algorithm:")

start_time = time.time()
if algorithm == 'bt':
	result = backtracking_search(k)
elif algorithm == 'btmrv':
	result = backtracking_search(k,select_unassigned_variable=mrv)
elif algorithm == 'fc':
	result = backtracking_search(k,inference = forward_checking)
elif algorithm == 'fcmrv':
	result = backtracking_search(k,select_unassigned_variable=mrv,inference = forward_checking)
print(result)
end_time = time.time()

print("Time: %s seconds" %(end_time-start_time))